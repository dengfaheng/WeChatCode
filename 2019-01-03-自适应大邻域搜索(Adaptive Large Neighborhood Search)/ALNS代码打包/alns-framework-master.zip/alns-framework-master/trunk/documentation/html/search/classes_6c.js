var searchData=
[
  ['linearcoolingschedule',['LinearCoolingSchedule',['../classLinearCoolingSchedule.html',1,'']]]
];
