var searchData=
[
  ['nbthresholds',['nbThresholds',['../classCoolingSchedule__Parameters.html#a0975632fdd8eef8bbdb843d3898e6813',1,'CoolingSchedule_Parameters']]]
];
