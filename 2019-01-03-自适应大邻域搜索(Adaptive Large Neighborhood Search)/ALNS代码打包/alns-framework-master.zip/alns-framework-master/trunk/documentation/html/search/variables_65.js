var searchData=
[
  ['exppercentagekept',['expPercentageKept',['../classCoolingSchedule__Parameters.html#a288ef5bba5e1b04f1e00c83a8664f7b8',1,'CoolingSchedule_Parameters']]]
];
