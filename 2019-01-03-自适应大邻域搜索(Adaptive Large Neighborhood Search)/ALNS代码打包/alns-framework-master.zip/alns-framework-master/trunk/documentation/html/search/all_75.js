var searchData=
[
  ['unsetnoise',['unsetNoise',['../classAOperator.html#ab1d6a25e233ec1383b9919f8dff098f1',1,'AOperator']]],
  ['updatescores',['updateScores',['../classAOperatorManager.html#afb87eb820180a129287658c9a55487a0',1,'AOperatorManager::updateScores()'],['../classOperatorManager.html#a06445bfd3151e3dfa51b06ab1664a7c7',1,'OperatorManager::updateScores()']]],
  ['uselocalsearch',['useLocalSearch',['../classILocalSearchManager.html#ab12f478c7be7163b674374ba478f2cbd',1,'ILocalSearchManager::useLocalSearch()'],['../classSimpleLocalSearchManager.html#a213c380b351e4c7c4b4948ad7da513a7',1,'SimpleLocalSearchManager::useLocalSearch()']]]
];
