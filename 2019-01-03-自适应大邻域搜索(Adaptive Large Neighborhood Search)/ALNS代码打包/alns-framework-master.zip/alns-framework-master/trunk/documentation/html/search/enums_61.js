var searchData=
[
  ['acceptancecriteriokind',['AcceptanceCriterioKind',['../classALNS__Parameters.html#addd5421947a7a1a533fec576f37560c7',1,'ALNS_Parameters']]]
];
