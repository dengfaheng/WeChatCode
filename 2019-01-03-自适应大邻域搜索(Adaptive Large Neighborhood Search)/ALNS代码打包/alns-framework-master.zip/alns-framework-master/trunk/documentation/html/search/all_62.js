var searchData=
[
  ['begin',['begin',['../classIBestSolutionManager.html#ab4f9c16464364b2a3b9b45a0453a32d1',1,'IBestSolutionManager::begin()'],['../classSimpleBestSolutionManager.html#a3dda02789fdfd353d0759567d5514977',1,'SimpleBestSolutionManager::begin()']]]
];
