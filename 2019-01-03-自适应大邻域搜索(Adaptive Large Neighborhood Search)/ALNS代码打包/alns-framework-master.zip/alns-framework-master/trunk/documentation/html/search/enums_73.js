var searchData=
[
  ['state',['State',['../classALNS__Iteration__Status.html#a6d748b05080edeab9e82ac32c9904133',1,'ALNS_Iteration_Status']]],
  ['stoppingcriteria',['StoppingCriteria',['../classALNS__Parameters.html#ae252d050b207dee5b442ca7d02c1d831',1,'ALNS_Parameters']]]
];
