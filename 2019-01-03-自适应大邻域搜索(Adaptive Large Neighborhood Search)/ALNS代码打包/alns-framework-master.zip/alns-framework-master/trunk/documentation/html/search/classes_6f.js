var searchData=
[
  ['operatormanager',['OperatorManager',['../classOperatorManager.html',1,'']]]
];
