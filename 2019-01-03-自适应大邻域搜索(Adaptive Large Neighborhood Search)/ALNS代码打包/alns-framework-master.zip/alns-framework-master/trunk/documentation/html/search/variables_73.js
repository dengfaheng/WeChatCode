var searchData=
[
  ['setuppercentage',['setupPercentage',['../classCoolingSchedule__Parameters.html#a11baeae90fe80f917c33703e8b456f32',1,'CoolingSchedule_Parameters']]],
  ['stats',['stats',['../classAOperatorManager.html#af08976002885d641241f160e0e419396',1,'AOperatorManager']]]
];
