var searchData=
[
  ['operator_3c',['operator<',['../classISolution.html#a9293d9e9eb00bab08dc25d11c61a1410',1,'ISolution']]],
  ['operatormanager',['OperatorManager',['../classOperatorManager.html#ae4f84de6b7812b951ee202e8c2afe478',1,'OperatorManager']]]
];
