cd Release
make clean
make

